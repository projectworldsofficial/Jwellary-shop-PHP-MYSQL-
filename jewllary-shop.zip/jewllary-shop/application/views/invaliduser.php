<div class="container" style="margin-top: 50px; text-align: center">
    <h1>Sorry</h1>
    <h1><i class="glyphicon glyphicon-thumbs-down"></i>&nbsp; You have no rights to access this page !</h1>
</div>